angular.module('main-app', 
[, 
'home-app', 
'nav-app'
])